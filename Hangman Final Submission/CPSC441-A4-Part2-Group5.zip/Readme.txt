Group 5 - T04
Robbie Karg 
Austin Graham
Bruin Kunnas
Cody Clark

Compile everything first
Run SelectServer <PortNumber>
Run TCPCLient2 <IP of server> <PortNumber>
All commands are given once connected and logged in

All accounts are in the Accounts.txt file
There is a total of 4 accounts, increasing numbers from the one below


Example for logging in:
login user1 1
"Successful login."

Example for setting a game word:
/setWord pineapple
"New word successfully set."

Example for guess letter:
/gl e

Example for listing all guesses:
/guesses

Example for logout, doesn't affect other users:
/logout

Example of kick/ban:
/kick user2

Example for logout (disconnects single user from server):
/quit

Example for unknown command:
/test
"I'm sorry but that doesn't look like a recognized command."
"Please try again."
